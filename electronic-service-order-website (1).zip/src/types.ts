export interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
  priceRange: string;
  features: string[];
}

export interface OrderFormData {
  name: string;
  phone: string;
  email: string;
  address: string;
  category: string;
  device: string;
  brand: string;
  problem: string;
  serviceType: string;
  date: string;
  notes: string;
}

export interface OrderStatus {
  orderId: string;
  status: 'pending' | 'diagnosing' | 'waiting_parts' | 'repairing' | 'completed' | 'cancelled';
  statusLabel: string;
  progress: number;
  customerName: string;
  deviceType: string;
  serviceCategory: string;
  submittedDate: string;
  estimatedCompletion: string;
  timeline: TimelineEntry[];
}

export interface TimelineEntry {
  date: string;
  time: string;
  status: string;
  description: string;
  icon: string;
}
