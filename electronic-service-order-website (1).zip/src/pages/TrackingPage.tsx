import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ArrowLeft, Clock, AlertCircle } from 'lucide-react';
import { statusColors } from '../data/services';

interface DemoOrder {
  orderId: string;
  status: string;
  statusLabel: string;
  progress: number;
  customerName: string;
  deviceType: string;
  serviceCategory: string;
  submittedDate: string;
  estimatedCompletion: string;
  timeline: {
    date: string;
    time: string;
    status: string;
    description: string;
    icon: string;
  }[];
}

const demoOrders: Record<string, DemoOrder> = {
  'US-DEMO001': {
    orderId: 'US-DEMO001',
    status: 'repairing',
    statusLabel: 'Sedang Diperbaiki',
    progress: 60,
    customerName: 'Budi Santoso',
    deviceType: 'HP Samsung Galaxy A54',
    serviceCategory: 'Service HP',
    submittedDate: '2025-01-10',
    estimatedCompletion: '2025-01-14',
    timeline: [
      { date: '2025-01-10', time: '09:30', status: 'Order Diterima', description: 'Order service telah diterima dan dikonfirmasi', icon: '📋' },
      { date: '2025-01-10', time: '14:00', status: 'Diagnosa', description: 'Teknisi sedang melakukan diagnosa perangkat', icon: '🔍' },
      { date: '2025-01-11', time: '10:00', status: 'Menunggu Sparepart', description: 'Memerlukan penggantian LCD, menunggu sparepart', icon: '📦' },
      { date: '2025-01-12', time: '08:00', status: 'Sedang Diperbaiki', description: 'Sparepart sudah tersedia, teknisi sedang mengerjakan', icon: '🔧' },
    ],
  },
  'US-DEMO002': {
    orderId: 'US-DEMO002',
    status: 'completed',
    statusLabel: 'Selesai',
    progress: 100,
    customerName: 'Siti Rahayu',
    deviceType: 'Laptop ASUS VivoBook 14',
    serviceCategory: 'Service Laptop',
    submittedDate: '2025-01-05',
    estimatedCompletion: '2025-01-08',
    timeline: [
      { date: '2025-01-05', time: '10:00', status: 'Order Diterima', description: 'Order service telah diterima', icon: '📋' },
      { date: '2025-01-05', time: '15:00', status: 'Diagnosa', description: 'Diagnosa: perlu upgrade SSD dan install ulang OS', icon: '🔍' },
      { date: '2025-01-06', time: '09:00', status: 'Sedang Diperbaiki', description: 'Proses upgrade SSD dan install Windows 11', icon: '🔧' },
      { date: '2025-01-07', time: '16:00', status: 'Selesai', description: 'Perbaikan selesai. Laptop sudah siap diambil.', icon: '✅' },
    ],
  },
  'US-DEMO003': {
    orderId: 'US-DEMO003',
    status: 'diagnosing',
    statusLabel: 'Sedang Diagnosa',
    progress: 30,
    customerName: 'Ahmad Fauzi',
    deviceType: 'TV LED Samsung 43"',
    serviceCategory: 'Service TV',
    submittedDate: '2025-01-13',
    estimatedCompletion: '2025-01-17',
    timeline: [
      { date: '2025-01-13', time: '11:00', status: 'Order Diterima', description: 'Order service telah diterima', icon: '📋' },
      { date: '2025-01-13', time: '14:30', status: 'Sedang Diagnosa', description: 'Teknisi memeriksa masalah garis pada layar TV', icon: '🔍' },
    ],
  },
};

export default function TrackingPage() {
  const [searchId, setSearchId] = useState('');
  const [order, setOrder] = useState<DemoOrder | null>(null);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = () => {
    setError('');
    setSearched(true);
    const trimmed = searchId.trim().toUpperCase();
    if (!trimmed) {
      setError('Masukkan nomor order');
      setOrder(null);
      return;
    }
    const found = demoOrders[trimmed];
    if (found) {
      setOrder(found);
    } else {
      setOrder(null);
      setError('Nomor order tidak ditemukan. Coba: US-DEMO001, US-DEMO002, atau US-DEMO003');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 md:py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-gray-500 hover:text-blue-600 transition-colors mb-4 text-sm font-medium">
            <ArrowLeft className="h-4 w-4" />
            Kembali ke Beranda
          </Link>
          <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900">
            Cek Status Service
          </h1>
          <p className="text-gray-500 mt-1">Masukkan nomor order untuk melihat status perbaikan</p>
        </div>

        {/* Search Box */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Masukkan nomor order (contoh: US-DEMO001)"
                className="w-full pl-12 pr-4 py-3.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-lg font-medium tracking-wide"
              />
            </div>
            <button
              onClick={handleSearch}
              className="bg-blue-600 text-white px-6 py-3.5 rounded-xl font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap"
            >
              Cari
            </button>
          </div>
          {error && (
            <p className="text-red-500 text-sm mt-3 flex items-center gap-2">
              <AlertCircle className="h-4 w-4 flex-shrink-0" /> {error}
            </p>
          )}
        </div>

        {/* Demo Orders Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 text-sm">
          <p className="font-semibold text-blue-700 mb-2">📌 Nomor Order Demo (untuk mencoba):</p>
          <div className="flex flex-wrap gap-2">
            {Object.keys(demoOrders).map((id) => (
              <button
                key={id}
                onClick={() => {
                  setSearchId(id);
                  setSearched(false);
                  setError('');
                  setOrder(null);
                }}
                className="bg-white border border-blue-200 px-3 py-1.5 rounded-lg text-blue-600 font-mono font-semibold hover:bg-blue-100 transition-colors text-xs"
              >
                {id}
              </button>
            ))}
          </div>
        </div>

        {/* Order Result */}
        {order && (
          <div className="space-y-6">
            {/* Order Info Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Nomor Order</p>
                  <p className="text-xl font-extrabold text-gray-900 tracking-wider">{order.orderId}</p>
                </div>
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold border ${statusColors[order.status] || 'bg-gray-100 text-gray-700 border-gray-300'}`}>
                  <div className={`w-2 h-2 rounded-full ${order.status === 'completed' ? 'bg-green-500' : order.status === 'cancelled' ? 'bg-red-500' : 'bg-blue-500 animate-pulse'}`}></div>
                  {order.statusLabel}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-500">Progress Perbaikan</span>
                  <span className="font-bold text-blue-600">{order.progress}%</span>
                </div>
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-1000 ${
                      order.status === 'completed'
                        ? 'bg-green-500'
                        : order.status === 'cancelled'
                        ? 'bg-red-500'
                        : 'bg-blue-500'
                    }`}
                    style={{ width: `${order.progress}%` }}
                  ></div>
                </div>
              </div>

              {/* Order Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-xs text-gray-500 font-medium mb-1">Nama Pelanggan</p>
                  <p className="font-semibold text-gray-900">{order.customerName}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-xs text-gray-500 font-medium mb-1">Perangkat</p>
                  <p className="font-semibold text-gray-900">{order.deviceType}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-xs text-gray-500 font-medium mb-1">Kategori Service</p>
                  <p className="font-semibold text-gray-900">{order.serviceCategory}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-xs text-gray-500 font-medium mb-1">Tanggal Masuk</p>
                  <p className="font-semibold text-gray-900">{order.submittedDate}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4 sm:col-span-2">
                  <p className="text-xs text-gray-500 font-medium mb-1">Estimasi Selesai</p>
                  <p className="font-semibold text-gray-900">{order.estimatedCompletion}</p>
                </div>
              </div>
            </div>

            {/* Timeline */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Clock className="h-5 w-5 text-blue-600" />
                Riwayat Status
              </h3>

              <div className="space-y-0">
                {order.timeline.map((entry, i) => (
                  <div key={i} className="flex gap-4">
                    {/* Timeline Line & Dot */}
                    <div className="flex flex-col items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg flex-shrink-0 ${
                        i === order.timeline.length - 1
                          ? 'bg-blue-100 border-2 border-blue-500'
                          : 'bg-gray-100'
                      }`}>
                        {entry.icon}
                      </div>
                      {i < order.timeline.length - 1 && (
                        <div className="w-0.5 h-full bg-gray-200 min-h-[40px]"></div>
                      )}
                    </div>

                    {/* Content */}
                    <div className={`pb-8 ${i === order.timeline.length - 1 ? 'pb-0' : ''}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-gray-900 text-sm">{entry.status}</span>
                        {i === order.timeline.length - 1 && (
                          <span className="bg-blue-100 text-blue-600 text-xs px-2 py-0.5 rounded-full font-semibold">
                            Terkini
                          </span>
                        )}
                      </div>
                      <p className="text-gray-500 text-sm mb-1">{entry.description}</p>
                      <p className="text-xs text-gray-400">{entry.date} • {entry.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {searched && !order && !error && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">Order Tidak Ditemukan</h3>
            <p className="text-gray-500 text-sm">
              Nomor order yang Anda masukkan tidak ditemukan. Periksa kembali nomor order Anda.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
