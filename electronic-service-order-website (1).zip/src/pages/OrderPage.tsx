import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  User, Package, Calendar,
  FileText, ArrowLeft, Send, AlertCircle, CheckCircle
} from 'lucide-react';
import { serviceCategories, serviceTypes } from '../data/services';
import type { OrderFormData } from '../types';

const initialFormData: OrderFormData = {
  name: '',
  phone: '',
  email: '',
  address: '',
  category: '',
  device: '',
  brand: '',
  problem: '',
  serviceType: 'dropoff',
  date: '',
  notes: '',
};

export default function OrderPage() {
  const [searchParams] = useSearchParams();
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [formData, setFormData] = useState<OrderFormData>(initialFormData);
  const [errors, setErrors] = useState<Partial<Record<keyof OrderFormData, string>>>({});

  useEffect(() => {
    const categoryParam = searchParams.get('category');
    if (categoryParam) {
      setFormData((prev) => ({ ...prev, category: categoryParam }));
    }
  }, [searchParams]);

  const updateField = (field: keyof OrderFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const validateStep1 = () => {
    const newErrors: Partial<Record<keyof OrderFormData, string>> = {};
    if (!formData.name.trim()) newErrors.name = 'Nama wajib diisi';
    if (!formData.phone.trim()) newErrors.phone = 'Nomor telepon wajib diisi';
    else if (!/^\d{10,13}$/.test(formData.phone.replace(/[\s-]/g, '')))
      newErrors.phone = 'Nomor telepon tidak valid';
    if (!formData.email.trim()) newErrors.email = 'Email wajib diisi';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = 'Format email tidak valid';
    if (!formData.address.trim()) newErrors.address = 'Alamat wajib diisi';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Partial<Record<keyof OrderFormData, string>> = {};
    if (!formData.category) newErrors.category = 'Pilih kategori service';
    if (!formData.device.trim()) newErrors.device = 'Jenis perangkat wajib diisi';
    if (!formData.brand.trim()) newErrors.brand = 'Merek perangkat wajib diisi';
    if (!formData.problem.trim()) newErrors.problem = 'Deskripsi masalah wajib diisi';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep3 = () => {
    const newErrors: Partial<Record<keyof OrderFormData, string>> = {};
    if (!formData.serviceType) newErrors.serviceType = 'Pilih metode service';
    if (!formData.date) newErrors.date = 'Tanggal wajib diisi';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (step === 1 && validateStep1()) setStep(2);
    else if (step === 2 && validateStep2()) setStep(3);
    else if (step === 3 && validateStep3()) setStep(4);
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
      setErrors({});
    }
  };

  const generateOrderId = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = 'US-';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const handleSubmit = () => {
    const newOrderId = generateOrderId();
    setOrderId(newOrderId);
    setSubmitted(true);
  };

  const selectedCategory = serviceCategories.find((c) => c.id === formData.category);
  const selectedServiceType = serviceTypes.find((s) => s.id === formData.serviceType);

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 max-w-lg w-full text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Order Berhasil! 🎉</h2>
          <p className="text-gray-500 mb-6">
            Terima kasih, <strong>{formData.name}</strong>! Order service Anda telah kami terima.
          </p>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-5 mb-6">
            <p className="text-sm text-blue-600 font-medium mb-1">Nomor Order Anda</p>
            <p className="text-2xl font-extrabold text-blue-700 tracking-wider">{orderId}</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-5 mb-6 text-left space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Perangkat</span>
              <span className="font-medium text-gray-900">{formData.device} - {formData.brand}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Service</span>
              <span className="font-medium text-gray-900">{selectedCategory?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Metode</span>
              <span className="font-medium text-gray-900">{selectedServiceType?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Tanggal</span>
              <span className="font-medium text-gray-900">{formData.date}</span>
            </div>
          </div>
          <p className="text-xs text-gray-400 mb-6">
            Simpan nomor order Anda untuk mengecek status perbaikan. Kami akan menghubungi Anda melalui telepon/email.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Link
              to="/tracking"
              className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Cek Status Order
            </Link>
            <Link
              to="/"
              className="flex-1 bg-gray-100 text-gray-700 px-6 py-3 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
            >
              Kembali ke Beranda
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 md:py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-gray-500 hover:text-blue-600 transition-colors mb-4 text-sm font-medium">
            <ArrowLeft className="h-4 w-4" />
            Kembali ke Beranda
          </Link>
          <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900">
            Order Service Elektronik
          </h1>
          <p className="text-gray-500 mt-1">Isi form berikut untuk memesan jasa service</p>
        </div>

        {/* Progress Steps */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
          <div className="flex items-center justify-between">
            {[
              { num: 1, label: 'Data Diri', icon: User },
              { num: 2, label: 'Detail Perangkat', icon: Package },
              { num: 3, label: 'Jadwal & Metode', icon: Calendar },
              { num: 4, label: 'Konfirmasi', icon: FileText },
            ].map((s, i) => (
              <div key={s.num} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                      step > s.num
                        ? 'bg-green-500 text-white'
                        : step === s.num
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {step > s.num ? '✓' : s.num}
                  </div>
                  <span
                    className={`text-xs mt-2 font-medium hidden sm:block ${
                      step >= s.num ? 'text-blue-600' : 'text-gray-400'
                    }`}
                  >
                    {s.label}
                  </span>
                </div>
                {i < 3 && (
                  <div
                    className={`h-1 flex-1 mx-2 rounded-full transition-all ${
                      step > s.num ? 'bg-green-500' : 'bg-gray-100'
                    }`}
                  ></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
          {/* Step 1: Data Diri */}
          {step === 1 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-blue-100 p-2.5 rounded-xl">
                  <User className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-gray-900">Data Diri</h2>
                  <p className="text-sm text-gray-500">Informasi kontak Anda</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Nama Lengkap <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  placeholder="Masukkan nama lengkap"
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.name ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                />
                {errors.name && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Nomor Telepon <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => updateField('phone', e.target.value)}
                  placeholder="Contoh: 081234567890"
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.phone ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                />
                {errors.phone && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.phone}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="contoh@email.com"
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.email ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                />
                {errors.email && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Alamat <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={formData.address}
                  onChange={(e) => updateField('address', e.target.value)}
                  placeholder="Masukkan alamat lengkap"
                  rows={3}
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.address ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none`}
                />
                {errors.address && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.address}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Step 2: Detail Perangkat */}
          {step === 2 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-purple-100 p-2.5 rounded-xl">
                  <Package className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-gray-900">Detail Perangkat</h2>
                  <p className="text-sm text-gray-500">Informasi perangkat yang akan diservice</p>
                </div>
              </div>

              {/* Category Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Kategori Service <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {serviceCategories.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => updateField('category', cat.id)}
                      className={`p-3 rounded-xl border-2 text-center transition-all ${
                        formData.category === cat.id
                          ? 'border-blue-500 bg-blue-50 shadow-sm'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="text-2xl mb-1">{cat.icon}</div>
                      <div className="text-xs font-semibold text-gray-700">{cat.name}</div>
                    </button>
                  ))}
                </div>
                {errors.category && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.category}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Jenis Perangkat <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.device}
                  onChange={(e) => updateField('device', e.target.value)}
                  placeholder="Contoh: HP Samsung Galaxy S23"
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.device ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                />
                {errors.device && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.device}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Merek Perangkat <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.brand}
                  onChange={(e) => updateField('brand', e.target.value)}
                  placeholder="Contoh: Samsung, ASUS, Philips"
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.brand ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                />
                {errors.brand && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.brand}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Deskripsi Masalah <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={formData.problem}
                  onChange={(e) => updateField('problem', e.target.value)}
                  placeholder="Jelaskan masalah yang dialami perangkat Anda secara detail"
                  rows={4}
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.problem ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none`}
                />
                {errors.problem && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.problem}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Step 3: Jadwal & Metode */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-green-100 p-2.5 rounded-xl">
                  <Calendar className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-gray-900">Jadwal & Metode Service</h2>
                  <p className="text-sm text-gray-500">Pilih cara dan waktu service</p>
                </div>
              </div>

              {/* Service Type */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Metode Service <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {serviceTypes.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => updateField('serviceType', type.id)}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        formData.serviceType === type.id
                          ? 'border-blue-500 bg-blue-50 shadow-sm'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="text-2xl mb-2">{type.icon}</div>
                      <div className="font-semibold text-gray-900 text-sm">{type.name}</div>
                      <div className="text-xs text-gray-500 mt-0.5">{type.desc}</div>
                    </button>
                  ))}
                </div>
                {errors.serviceType && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.serviceType}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Tanggal Service <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => updateField('date', e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  className={`w-full px-4 py-3 rounded-xl border ${
                    errors.date ? 'border-red-300 bg-red-50' : 'border-gray-200'
                  } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                />
                {errors.date && (
                  <p className="text-red-500 text-xs mt-1.5 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.date}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Catatan Tambahan
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => updateField('notes', e.target.value)}
                  placeholder="Catatan tambahan (opsional)"
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                />
              </div>
            </div>
          )}

          {/* Step 4: Konfirmasi */}
          {step === 4 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-yellow-100 p-2.5 rounded-xl">
                  <FileText className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-gray-900">Konfirmasi Order</h2>
                  <p className="text-sm text-gray-500">Periksa kembali data order Anda</p>
                </div>
              </div>

              {/* Data Diri */}
              <div className="bg-gray-50 rounded-xl p-5">
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <User className="h-4 w-4 text-blue-600" /> Data Diri
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Nama</span>
                    <span className="font-medium text-gray-900">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Telepon</span>
                    <span className="font-medium text-gray-900">{formData.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Email</span>
                    <span className="font-medium text-gray-900">{formData.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Alamat</span>
                    <span className="font-medium text-gray-900 text-right max-w-[60%]">{formData.address}</span>
                  </div>
                </div>
              </div>

              {/* Detail Perangkat */}
              <div className="bg-gray-50 rounded-xl p-5">
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <Package className="h-4 w-4 text-purple-600" /> Detail Perangkat
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Kategori</span>
                    <span className="font-medium text-gray-900">
                      {selectedCategory?.icon} {selectedCategory?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Perangkat</span>
                    <span className="font-medium text-gray-900">{formData.device}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Merek</span>
                    <span className="font-medium text-gray-900">{formData.brand}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Masalah</span>
                    <p className="font-medium text-gray-900 mt-1">{formData.problem}</p>
                  </div>
                </div>
              </div>

              {/* Jadwal & Metode */}
              <div className="bg-gray-50 rounded-xl p-5">
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-green-600" /> Jadwal & Metode
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Metode</span>
                    <span className="font-medium text-gray-900">
                      {selectedServiceType?.icon} {selectedServiceType?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Tanggal</span>
                    <span className="font-medium text-gray-900">{formData.date}</span>
                  </div>
                  {formData.notes && (
                    <div>
                      <span className="text-gray-500">Catatan</span>
                      <p className="font-medium text-gray-900 mt-1">{formData.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-sm text-yellow-700">
                <p className="font-semibold mb-1">⚠️ Catatan Penting</p>
                <p>Dengan mengirim order ini, Anda menyetujui bahwa teknisi kami akan melakukan diagnosa terlebih dahulu dan memberikan estimasi biaya sebelum melakukan perbaikan.</p>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
            {step > 1 ? (
              <button
                onClick={prevStep}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-gray-600 font-semibold hover:bg-gray-100 transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                Sebelumnya
              </button>
            ) : (
              <div></div>
            )}

            {step < 4 ? (
              <button
                onClick={nextStep}
                className="inline-flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-sm"
              >
                Selanjutnya
                <ArrowLeft className="h-4 w-4 rotate-180" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="inline-flex items-center gap-2 bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors shadow-sm"
              >
                <Send className="h-4 w-4" />
                Kirim Order
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
