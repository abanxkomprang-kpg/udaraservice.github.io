import { Link } from 'react-router-dom';
import {
  Wrench, Clock, Shield, Truck, Star,
  ArrowRight, Phone, ChevronRight
} from 'lucide-react';
import { serviceCategories } from '../data/services';

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-300 rounded-full blur-3xl"></div>
          <div className="absolute top-40 right-40 w-48 h-48 bg-yellow-300 rounded-full blur-3xl"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Star className="h-4 w-4 text-yellow-400" />
                <span>Rating 4.9/5 dari 10.000+ pelanggan</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-6">
                Service Elektronik
                <span className="block text-yellow-400">Cepat & Terpercaya</span>
              </h1>
              <p className="text-lg text-blue-100 mb-8 leading-relaxed max-w-lg">
                Perbaikan HP, Laptop, TV, Lampu, Kipas Angin, Amplifier, dan Magicom oleh teknisi profesional berpengalaman. Garansi service hingga 3 bulan!
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/order"
                  className="inline-flex items-center justify-center gap-2 bg-yellow-400 text-gray-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-yellow-300 transition-all shadow-lg shadow-yellow-400/30 hover:shadow-yellow-400/50 hover:-translate-y-0.5"
                >
                  <Wrench className="h-5 w-5" />
                  Order Service
                </Link>
                <Link
                  to="/tracking"
                  className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all border border-white/20"
                >
                  <Phone className="h-5 w-5" />
                  Cek Status
                </Link>
              </div>
            </div>
            <div className="hidden md:flex justify-center">
              <div className="relative">
                <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20">
                  <div className="text-8xl mb-4">🔧</div>
                  <div className="grid grid-cols-4 gap-3">
                    {['📱', '💻', '📺', '💡', '🌀', '🔊', '🍚'].map((icon, i) => (
                      <div
                        key={i}
                        className="bg-white/10 rounded-xl p-3 text-center text-3xl hover:bg-white/20 transition-colors cursor-default"
                      >
                        {icon}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 px-4 py-2 rounded-xl font-bold text-sm shadow-lg animate-bounce">
                  Garansi 3 Bulan!
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-8 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { number: '10,000+', label: 'Pelanggan Puas', icon: '👥' },
              { number: '15,000+', label: 'Service Selesai', icon: '✅' },
              { number: '4.9/5', label: 'Rating Google', icon: '⭐' },
              { number: '8+', label: 'Tahun Pengalaman', icon: '🏆' },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl mb-2">{stat.icon}</div>
                <div className="text-2xl md:text-3xl font-extrabold text-blue-600">{stat.number}</div>
                <div className="text-sm text-gray-500 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="inline-block bg-blue-100 text-blue-600 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
              Layanan Kami
            </span>
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4">
              7 Kategori Service Elektronik
            </h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto">
              Kami melayani perbaikan berbagai jenis elektronik rumah tangga dan gadget dengan teknisi profesional
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {serviceCategories.map((category) => (
              <Link
                key={category.id}
                to={`/order?category=${category.id}`}
                className="group bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl border border-gray-100 hover:border-blue-200 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="text-5xl mb-4 group-hover:scale-110 transition-transform duration-300">
                  {category.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {category.name}
                </h3>
                <p className="text-gray-500 text-sm mb-4 leading-relaxed">
                  {category.description}
                </p>
                <div className="bg-blue-50 text-blue-600 px-3 py-1.5 rounded-lg text-sm font-semibold inline-block mb-4">
                  {category.priceRange}
                </div>
                <div className="flex items-center text-blue-600 font-semibold text-sm group-hover:gap-3 gap-2 transition-all">
                  <span>Order Sekarang</span>
                  <ChevronRight className="h-4 w-4" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="inline-block bg-green-100 text-green-600 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
              Mengapa Memilih Kami
            </span>
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4">
              Keunggulan Udara Service
            </h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto">
              Komitmen kami untuk memberikan layanan service terbaik dengan kualitas tinggi
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Shield,
                title: 'Garansi 3 Bulan',
                desc: 'Setiap perbaikan bergaransi 3 bulan. Jika masalah sama muncul lagi, kami perbaiki gratis.',
                color: 'bg-green-100 text-green-600',
              },
              {
                icon: Clock,
                title: 'Pengerjaan Cepat',
                desc: 'Sebagian besar perbaikan selesai dalam 1-3 hari kerja. Express service tersedia.',
                color: 'bg-blue-100 text-blue-600',
              },
              {
                icon: Truck,
                title: 'Pickup & Delivery',
                desc: 'Layanan antar jemput perangkat gratis untuk area Jakarta dan sekitarnya.',
                color: 'bg-purple-100 text-purple-600',
              },
              {
                icon: Wrench,
                title: 'Teknisi Profesional',
                desc: 'Tim teknisi bersertifikat dengan pengalaman lebih dari 8 tahun di bidangnya.',
                color: 'bg-orange-100 text-orange-600',
              },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-gray-50 rounded-2xl p-6 hover:bg-white hover:shadow-lg border border-transparent hover:border-gray-100 transition-all duration-300"
              >
                <div className={`${item.color} w-14 h-14 rounded-xl flex items-center justify-center mb-5`}>
                  <item.icon className="h-7 w-7" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="inline-block bg-indigo-100 text-indigo-600 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
              Cara Kerja
            </span>
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4">
              4 Langkah Mudah
            </h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto">
              Proses service yang simpel dan transparan dari awal hingga selesai
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Order Online',
                desc: 'Isi form order dengan detail perangkat dan masalah yang dialami',
                icon: '📝',
              },
              {
                step: '02',
                title: 'Diagnosa Gratis',
                desc: 'Teknisi kami akan mendiagnosa perangkat dan memberikan estimasi biaya',
                icon: '🔍',
              },
              {
                step: '03',
                title: 'Proses Perbaikan',
                desc: 'Setelah disetujui, teknisi langsung mengerjakan perbaikan perangkat Anda',
                icon: '🔧',
              },
              {
                step: '04',
                title: 'Selesai & Garansi',
                desc: 'Perangkat siap diambil/diantar dengan garansi service hingga 3 bulan',
                icon: '✅',
              },
            ].map((item, i) => (
              <div key={i} className="relative text-center">
                {i < 3 && (
                  <div className="hidden md:block absolute top-12 left-1/2 w-full h-0.5 bg-blue-200"></div>
                )}
                <div className="relative z-10">
                  <div className="bg-white rounded-2xl w-24 h-24 mx-auto flex items-center justify-center text-5xl shadow-lg mb-6 border-4 border-blue-100">
                    {item.icon}
                  </div>
                  <div className="inline-block bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full mb-3">
                    STEP {item.step}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-blue-600 to-indigo-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-20 w-64 h-64 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-20 w-80 h-80 bg-yellow-300 rounded-full blur-3xl"></div>
        </div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-4">
            Perangkat Anda Bermasalah?
          </h2>
          <p className="text-blue-100 text-lg mb-8 max-w-2xl mx-auto">
            Jangan tunda perbaikan! Order service sekarang dan dapatkan diagnosa GRATIS. Teknisi profesional kami siap membantu.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/order"
              className="inline-flex items-center justify-center gap-2 bg-yellow-400 text-gray-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-yellow-300 transition-all shadow-lg hover:-translate-y-0.5"
            >
              <Wrench className="h-5 w-5" />
              Order Service Sekarang
              <ArrowRight className="h-5 w-5" />
            </Link>
            <a
              href="tel:081234567890"
              className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all border border-white/20"
            >
              <Phone className="h-5 w-5" />
              Hubungi Kami
            </a>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="inline-block bg-yellow-100 text-yellow-600 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
              Testimoni
            </span>
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4">
              Apa Kata Pelanggan Kami
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: 'Budi Santoso',
                avatar: '👨',
                rating: 5,
                text: 'HP Samsung saya yang mati total bisa diperbaiki dalam 2 hari. Harga juga sangat terjangkau. Recommended banget!',
                service: 'Service HP',
              },
              {
                name: 'Siti Rahayu',
                avatar: '👩',
                rating: 5,
                text: 'Laptop ASUS saya yang lemot sekarang sudah kencang lagi setelah upgrade SSD. Teknisinya ramah dan profesional.',
                service: 'Service Laptop',
              },
              {
                name: 'Ahmad Fauzi',
                avatar: '👨‍💼',
                rating: 5,
                text: 'TV LED saya yang bergaris sudah normal lagi. Proses cepat dan ada garansi 3 bulan. Sangat puas dengan pelayanannya!',
                service: 'Service TV',
              },
            ].map((testimonial, i) => (
              <div
                key={i}
                className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-all"
              >
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="text-3xl">{testimonial.avatar}</div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{testimonial.name}</p>
                    <p className="text-blue-600 text-xs font-medium">{testimonial.service}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
