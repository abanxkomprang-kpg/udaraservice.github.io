import { Link } from 'react-router-dom';
import { Wrench, Phone, Mail, MapPin, Clock } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Wrench className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">
                Udara<span className="text-blue-400"> Service</span>
              </span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Jasa service elektronik terpercaya dengan teknisi berpengalaman.
              Kami melayani perbaikan HP, Laptop, TV, Lampu, Kipas Angin, Amplifier, dan Magicom.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Layanan Kami</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service HP</Link></li>
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service Laptop</Link></li>
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service TV</Link></li>
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service Lampu</Link></li>
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service Kipas Angin</Link></li>
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service Amplifier</Link></li>
              <li><Link to="/order" className="hover:text-blue-400 transition-colors">Service Magicom</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Kontak Kami</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <Phone className="h-4 w-4 mt-0.5 text-blue-400 flex-shrink-0" />
                <span>(021) 1234-5678<br />0812-3456-7890</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-4 w-4 mt-0.5 text-blue-400 flex-shrink-0" />
                <span>info@udaraservice.com</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 text-blue-400 flex-shrink-0" />
                <span>Jl. Rajawali, Kedungsono, Kec. Bulu,<br />Kabupaten Sukoharjo, Jawa Tengah 57563</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Jam Operasional</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 mt-0.5 text-blue-400 flex-shrink-0" />
                <div>
                  <p className="text-white">Senin - Jumat</p>
                  <p>08:00 - 20:00 WIB</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 mt-0.5 text-blue-400 flex-shrink-0" />
                <div>
                  <p className="text-white">Sabtu</p>
                  <p>08:00 - 17:00 WIB</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 mt-0.5 text-blue-400 flex-shrink-0" />
                <div>
                  <p className="text-white">Minggu & Hari Libur</p>
                  <p>09:00 - 15:00 WIB</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-10 pt-8 text-center text-sm text-gray-500">
          <p>&copy; 2025 Udara Service. Semua hak dilindungi.</p>
        </div>
      </div>
    </footer>
  );
}
