import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Wrench } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Wrench className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">
              Udara<span className="text-blue-600"> Service</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Beranda
            </Link>
            <Link to="/order" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Order Service
            </Link>
            <Link to="/tracking" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Cek Status
            </Link>
            <Link
              to="/order"
              className="bg-blue-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-blue-700 transition-colors shadow-sm"
            >
              Order Sekarang
            </Link>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 shadow-lg">
          <div className="px-4 py-4 space-y-2">
            <Link
              to="/"
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 rounded-lg text-gray-600 hover:bg-blue-50 hover:text-blue-600 font-medium transition-colors"
            >
              Beranda
            </Link>
            <Link
              to="/order"
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 rounded-lg text-gray-600 hover:bg-blue-50 hover:text-blue-600 font-medium transition-colors"
            >
              Order Service
            </Link>
            <Link
              to="/tracking"
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 rounded-lg text-gray-600 hover:bg-blue-50 hover:text-blue-600 font-medium transition-colors"
            >
              Cek Status
            </Link>
            <Link
              to="/order"
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 rounded-lg bg-blue-600 text-white font-semibold text-center hover:bg-blue-700 transition-colors"
            >
              Order Sekarang
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
