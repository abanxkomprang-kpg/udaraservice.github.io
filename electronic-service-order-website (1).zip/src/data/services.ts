import { ServiceCategory } from '../types';

export const serviceCategories: ServiceCategory[] = [
  {
    id: 'hp',
    name: 'Service HP',
    icon: '📱',
    description: 'Perbaikan smartphone semua merek: Samsung, iPhone, Xiaomi, OPPO, Vivo, dll',
    priceRange: 'Mulai Rp 50.000',
    features: ['Ganti LCD/Touchscreen', 'Ganti Baterai', 'Service Charging Port', 'Flash/Unlock Software', 'Service Speaker & Mic', 'Ganti Housing/Casing'],
  },
  {
    id: 'laptop',
    name: 'Service Laptop',
    icon: '💻',
    description: 'Perbaikan laptop & notebook semua merek: ASUS, Lenovo, HP, Dell, Acer, MacBook',
    priceRange: 'Mulai Rp 75.000',
    features: ['Install Ulang OS', 'Ganti Layar LCD/LED', 'Upgrade RAM & SSD', 'Service Motherboard', 'Ganti Keyboard', 'Service Engsel & Casing'],
  },
  {
    id: 'tv',
    name: 'Service TV',
    icon: '📺',
    description: 'Perbaikan TV LED, LCD, Smart TV semua merek: Samsung, LG, Sony, TCL, Polytron',
    priceRange: 'Mulai Rp 100.000',
    features: ['Service LED Backlight', 'Ganti Panel TV', 'Perbaikan Mainboard', 'Service Power Supply', 'Smart TV Setup', 'Service Tuner & Antena'],
  },
  {
    id: 'lampu',
    name: 'Service Lampu',
    icon: '💡',
    description: 'Perbaikan berbagai jenis lampu: LED, neon, lampu taman, lampu emergency',
    priceRange: 'Mulai Rp 30.000',
    features: ['Service Lampu LED', 'Perbaikan Lampu Neon', 'Service Lampu Taman', 'Lampu Emergency', 'Driver/Adapter Lampu', 'Instalasi Lampu Baru'],
  },
  {
    id: 'kipas_angin',
    name: 'Service Kipas Angin',
    icon: '🌀',
    description: 'Perbaikan kipas angin berdiri, dinding, meja, dan exhaust fan',
    priceRange: 'Mulai Rp 40.000',
    features: ['Ganti Dinamo/Motor', 'Perbaikan Speed Control', 'Ganti Baling-baling', 'Service Oscillation', 'Perbaikan Kabel & Saklar', 'Pembersihan & Pelumasan'],
  },
  {
    id: 'amplifier',
    name: 'Service Amplifier',
    icon: '🔊',
    description: 'Perbaikan amplifier, speaker aktif, home theater, dan sound system',
    priceRange: 'Mulai Rp 75.000',
    features: ['Service Power Amplifier', 'Perbaikan Equalizer', 'Ganti Transistor/IC', 'Service Mixer', 'Perbaikan Speaker Aktif', 'Service Home Theater'],
  },
  {
    id: 'magicom',
    name: 'Service Magicom',
    icon: '🍚',
    description: 'Perbaikan rice cooker/magicom semua merek: Philips, Miyako, Cosmos, Maspion',
    priceRange: 'Mulai Rp 35.000',
    features: ['Ganti Element Pemanas', 'Perbaikan Thermostat', 'Service Timer Digital', 'Ganti Inner Pot', 'Perbaikan Saklar/Magnet', 'Service Panel Kontrol'],
  },
];

export const statusLabels: Record<string, string> = {
  pending: 'Menunggu Konfirmasi',
  diagnosing: 'Sedang Diagnosa',
  waiting_parts: 'Menunggu Sparepart',
  repairing: 'Sedang Diperbaiki',
  completed: 'Selesai',
  cancelled: 'Dibatalkan',
};

export const statusColors: Record<string, string> = {
  pending: 'bg-gray-100 text-gray-700 border-gray-300',
  diagnosing: 'bg-yellow-100 text-yellow-700 border-yellow-300',
  waiting_parts: 'bg-orange-100 text-orange-700 border-orange-300',
  repairing: 'bg-blue-100 text-blue-700 border-blue-300',
  completed: 'bg-green-100 text-green-700 border-green-300',
  cancelled: 'bg-red-100 text-red-700 border-red-300',
};

export const serviceTypes = [
  { id: 'dropoff', name: 'Drop Off', icon: '🏪', desc: 'Antar sendiri ke tempat kami' },
  { id: 'pickup', name: 'Pick Up', icon: '🚚', desc: 'Kami jemput perangkat Anda' },
  { id: 'home', name: 'Home Service', icon: '🏠', desc: 'Teknisi datang ke rumah Anda' },
];
